const express = require('express')
const app = express()
const port = 8080
const bodyParser = require('body-parser')
const bookRouter = require('./routes/book-router')
const auth = require('./middlewares/auth')
const cors = require('cors')

app.listen(port, function () {
    console.log(`app listening on port ${port}!`)
})

app.use(bodyParser.json())
app.use(cors())
//app.use(auth)
app.use('/v1/books', bookRouter)

app.get('/', (req, res) => {
    res.status(200).send(`hello from book api!!!`)
})