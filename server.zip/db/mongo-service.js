const mongoose = require('mongoose')
const url = 'mongodb://localhost:27017/book-store'

const bookSchema = mongoose.Schema({
    title: {
        type: String
    },
    author: {
        type: String
    },
    category: {
        type: String
    },
    numberOfPages: {
        type: Number
    },
    yearOfPublication: {
        type: Number
    }
}, { collection: 'book' })

const Book = mongoose.model('Book', bookSchema)

mongoose.connect(url, { useNewUrlParser: true }, (err) => {
    if (err) {
        console.log(err)
    }
    console.log('book store connected')
})

const getBookByID = async (id) => {
    return await Book.findById(id)
}

const addBook = async (body) => {
    const book = new Book({
        title: body.title,
        author: body.author,
        category: body.category,
        numberOfPages: body.numberOfPages,
        yearOfPublication: body.yearOfPublication,
    })
    await book.save()
}

const deleteBook = async (id) => {
    const book = await Book.findById(id)
    await book.remove()
}

const updateBook = async (id, body) => {
    const book = await Book.findById(id)

    book.title = body.title
    book.author = body.author
    book.category = body.category
    book.numberOfPages = body.numberOfPages
    book.yearOfPublication = body.yearOfPublication

    await book.save()
}

module.exports = { Book, getBookByID, addBook, deleteBook, updateBook }