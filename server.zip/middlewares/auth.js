const auth = (req, res, next) => {
    const { authorization } = req.headers
    if(authorization) {
        const encode = authorization.split(' ')[1]
        const credentials = Buffer.from(encode, 'base64').toString()
        const user = credentials.split(':')[0]
        const pass = credentials.split(':')[1]
        
        if(user === "admin" & pass === "root") {
            return next()
        }
    }
    res.sendStatus(403)
}

module.exports = auth;