const express = require('express')
const router = express.Router()
const mongoService = require('./../db/mongo-service')

router.get('/', async (req, res) => {
    const result = await mongoService.Book.find()
    res.json(result)
})

router.post('/', async (req, res) => {
    const body = req.body

    try {
        await mongoService.addBook(body)
        res.sendStatus(201)
    } catch (err) {
        console.log(err)
        res.sendStatus(500)
    }
})

router.get('/:id', async (req, res) => {
    const { id } = req.params
    const result = await mongoService.getBookByID(id)
    res.json(result)
})

router.put('/:id', async (req, res) => {
    const { id } = req.params
    const body = req.body

    const result = await mongoService.updateBook(id, body)
    
    res.json(result)
})


router.delete('/:id', async (req, res) => {
    const { id } = req.params

    try {
        await mongoService.deleteBook(id)
        res.sendStatus(202)
    } catch (err) {
        console.log(err)
        res.sendStatus(500)
    }
})

module.exports = router