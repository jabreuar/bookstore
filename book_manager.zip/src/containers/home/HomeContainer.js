import React, { Component } from 'react'
import Home from './Home'

class HomeContainer extends Component {
  constructor (props) {
    super(props)

    this.state = {
      books: []
    }

    this.handleClickDelete = this.handleClickDelete.bind(this)
  }

  componentDidMount () {
    this.loadBooks()
  }

  async loadBooks () {
    const res = await fetch('http://localhost:8080/v1/books')
    const books = await res.json()

    this.setState(() => ({
      books
    }))
  }

  async handleClickDelete (bookId) {
    const confirm = window.confirm('Do you confirm?')

    if (confirm) {
      const res = await fetch(`http://localhost:8080/v1/books/${bookId}`, { method: 'delete' })
      if (res.ok) {
        this.loadBooks()
      } else {
        window.alert('Something went wrong')
      }
    }
  }

  render () {
    return (
      <Home books={this.state.books} onClickDelete={this.handleClickDelete} />
    )
  }
}

export default HomeContainer
