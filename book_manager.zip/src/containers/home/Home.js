import React from 'react';
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import './Home.css';

const Home = ({ books, onClickDelete }) => (
  <section className="Home">
    <div>
      <Link to="/books/new" className="button">
        Adicionar novo livro
      </Link>
    </div>
    <table>
      <thead>
        <tr>
          <th>Title</th>
          <th>Author</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {books.map(book => (
          <tr key={book._id}>
            <td>
              <Link to={`/books/${book._id}`}>
                {book.title}
              </Link>
            </td>
            <td>{book.author}</td>
            <td>
              <button onClick={() => onClickDelete(book._id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </section>
)

Home.propTypes = {
  books: PropTypes.array.isRequired
}

export default Home;
