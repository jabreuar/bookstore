import React, { Component } from 'react'
import { Redirect } from 'react-router-dom'
import Book from './Book'

class BookContainer extends Component {
  constructor (props) {
    super(props)

    this.state = {
      _id: '',
      title: '',
      author: '',
      category: '',
      numberOfPages: '',
      yearOfPublication: '',
      success: false
    }

    this.handleChangeField = this.handleChangeField.bind(this)
    this.handleSubmit = this.handleSubmit.bind(this)
  }

  componentDidMount () {
    const { bookId } = this.props.match.params

    if (bookId) {
      this.loadBook(bookId)
    }
  }

  async loadBook (bookId) {
    const res = await fetch(`http://localhost:8080/v1/books/${bookId}`)
    const book = await res.json()

    const {
      _id,
      title,
      author,
      category,
      numberOfPages,
      yearOfPublication } = book

    this.setState(() => ({
      _id, title, author, category,
      numberOfPages: numberOfPages.toString(),
      yearOfPublication: yearOfPublication.toString()
    }))
  }

  handleChangeField (e) {
    const { target: { name, value } } = e
    this.setState(() => ({ [name]: value }))
  }

  async handleSubmit (e) {
    e.preventDefault()
    
    const {
      _id,
      title,
      author,
      category,
      numberOfPages,
      yearOfPublication } = this.state

    const book = {
      title, author, category, numberOfPages, yearOfPublication
    }

    let res = { ok: false }

    if (_id) {
      res = await fetch(`http://localhost:8080/v1/books/${_id}`, {
        headers: { 'Content-Type': 'application/json' },
        method: 'put',
        body: JSON.stringify(book)
      })      
    } else {
      res = await fetch('http://localhost:8080/v1/books', {
        headers: { 'Content-Type': 'application/json' },
        method: 'post',
        body: JSON.stringify(book)
      })
    }

    if (res.ok) {
      this.setState(() => ({ success: true }))
    }
  }

  render () {
    return this.state.success
      ? <Redirect to='/' />
      : (
        <Book title={this.state.title}
          author={this.state.author}
          category={this.state.category}
          numberOfPages={this.state.numberOfPages}
          yearOfPublication={this.state.yearOfPublication}
          onChangeField={this.handleChangeField}
          onSubmit={this.handleSubmit} />
    )
  }
}

export default BookContainer
