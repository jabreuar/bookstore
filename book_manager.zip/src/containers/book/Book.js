import React from 'react';
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import './Book.css';

const Book = ({
  title,
  author,
  category,
  numberOfPages,
  yearOfPublication,
  onChangeField,
  onSubmit
}) => (
  <section className='Book'>
    <div>
      <Link to="/" className="button">
        Voltar
      </Link>
    </div>
    <form onSubmit={onSubmit}>
      <div>
        <label>Title<br/>
          <input type='text' name='title' value={title} onChange={onChangeField} autoFocus />
        </label>
      </div>
      <div>
        <label>Author<br/>
          <input type='text' name='author' value={author} onChange={onChangeField} />
        </label>
      </div>
      <div>
        <label>Category<br/>
          <select name='category' value={category} onChange={onChangeField}>
            <option value=''>--</option>
            <option>Biografia</option>
            <option>Ficção</option>
            <option>Romance</option>
            <option>Tecnologia</option>
          </select>
        </label>
      </div>
      <div>
        <label>Number of pages<br/>
          <input type="number" name='numberOfPages' value={numberOfPages} onChange={onChangeField} min={0} />
        </label>
      </div>
      <div>
        <label>Year of publication<br/>
          <input type="number" name='yearOfPublication' value={yearOfPublication} onChange={onChangeField} min={1900} max={2050} />
        </label>
      </div>
      <div>
        <button type="submit">Save</button>
      </div>
    </form>
  </section>
)

Book.propTypes = {
  title: PropTypes.string.isRequired,
  author: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  numberOfPages: PropTypes.string.isRequired,
  yearOfPublication: PropTypes.string.isRequired,
  onChangeField: PropTypes.func.isRequired,
  onSubmit: PropTypes.func.isRequired
}

export default Book;
